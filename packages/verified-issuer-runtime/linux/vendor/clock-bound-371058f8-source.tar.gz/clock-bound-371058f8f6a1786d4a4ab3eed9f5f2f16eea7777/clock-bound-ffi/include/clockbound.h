
#ifndef _CLOCKBOUND_H
#define _CLOCKBOUND_H

#include <time.h>

#define CLOCKBOUND_ERROR_DETAIL_SIZE 128
#define CLOCKBOUND_SHM_DEFAULT_PATH "/var/run/clockbound/shm1"
#define VMCLOCK_SHM_DEFAULT_PATH "/dev/vmclock0"

/*
 * ClockBound context structure (opaque).
 *
 * This structure is NOT thread safe, and should not be shared between threads.
 * Put slighly differently, each thread needs to open its own clockbound context.
 */
typedef struct clockbound_ctx clockbound_ctx;

/*
 * Enumeration of error codes.
 */
typedef enum clockbound_err_kind {
	/* No error. */
	CLOCKBOUND_ERR_NONE,
	/* Error returned by a syscall. */
	CLOCKBOUND_ERR_SYSCALL,
	/* A shared memory segment has not been initialized. */
	CLOCKBOUND_ERR_SEGMENT_NOT_INITIALIZED,
	/* A shared memory segment is initialized but malformed. */
	CLOCKBOUND_ERR_SEGMENT_MALFORMED,
	/* The system clock and shared memory segment reads do match expected order. */
	CLOCKBOUND_ERR_CAUSALITY_BREACH,
	/* A shared memory segment has a version format that is not supported. */
	CLOCKBOUND_ERR_SEGMENT_VERSION_NOT_SUPPORTED,
} clockbound_err_kind;

/*
 * Error type structure.
 */
typedef struct clockbound_err {
	/* The type of error which occurred. */
	clockbound_err_kind kind;
	/*
	 * For CLOCKBOUND_ERR_SYSCALL, the errno which was returned by the underlying
	 * system call. See documentation for the interpretation of errno for other
	 * clockbound_err_kind variants.
	 */
	int errno;
	/* Human readable context about the error, if available. */
	const char detail[CLOCKBOUND_ERROR_DETAIL_SIZE];
} clockbound_err;

/*
 * Enumeration of clock status.
 */
typedef enum clockbound_clock_status {
	/* The status of the clock is unknown, time cannot be trusted. */
	CLOCKBOUND_STA_UNKNOWN,
	/* The clock is synchronized to a reference time source. */
	CLOCKBOUND_STA_SYNCHRONIZED,
	/* The clock has lost synchronization but time can still be trusted. */
	CLOCKBOUND_STA_FREE_RUNNING,
	/* The clock has been disrupted, time should not be trusted. */
	CLOCKBOUND_STA_DISRUPTED,
} clockbound_clock_status;

/*
 * Clockbound result populating by the `clockbound_now()` operation.
 */
typedef struct clockbound_now_result {
	struct timespec earliest;
	struct timespec latest;
	clockbound_clock_status clock_status;
} clockbound_now_result;

/*
 * Open a new context using the ClockBound daemon-client segment and the VMClock segment
 * at their default path.
 *
 * Returns a newly-allocated context on success, and NULL on failure. If `err` is
 * non-null, fills `*err` with error details.
 */
clockbound_ctx* clockbound_open(clockbound_err *err);

/*
 * Open a new context using the ClockBound daemon-client segment at `clockbound_shm_path`
 * and the VMClock segment at `vmclock_shm_path`.
 *
 * Returns a newly-allocated context on success, and NULL on failure. If `err` is
 * non-null, fills `*err` with error details.
 */
clockbound_ctx* clockbound_open_with(char const* clockbound_shm_path,
		char const* vmclock_shm_path, clockbound_err *err);

/*
 * Close and deallocates the context.
 *
 * Returns NULL on success, or a pointer to `err` on failure. If err is non-null, fills
 * `*err` with error details.
 * */
clockbound_err* clockbound_close(clockbound_ctx *ctx, clockbound_err *err);

/*
 * Retrieve the Clock Error Bound interval.
 *
 * This function is the equivalent of `clock_gettime(CLOCK_REALTIME)` but in the context of
 * ClockBound. It reads the current time from the system clock (C(t)), and calculate the CEB at this
 * instant. This allows to return a pair of timespec structures that define the interval
 *     [(C(t) - CEB), (C(t) + CEB)]
 * in which true time exists.
 *
 * The call also populate `res` with the underlying clock status.
 * The clock status MUST be checked to ensure the bound on clock error is trustworthy.
 *
 * Returns NULL on success, or a pointer to `err` on failure. If err is non-null, fills
 * `*err` with error details.
 */
clockbound_err* clockbound_now(clockbound_ctx *ctx, clockbound_now_result *res, clockbound_err *err);

#endif

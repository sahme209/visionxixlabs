//! This module contains a newtype `Timex` wrapping an inner `libc::timex`, which allows construction
//! only of valid values for the sake of the types of `adjtimex`/`ntp_adjtime` calls we'll make in ClockBound.
use bon::bon;
#[cfg(not(target_os = "macos"))]
use libc::timeval;
use libc::{
    ADJ_SETOFFSET, MOD_ESTERROR, MOD_MAXERROR, MOD_NANO, MOD_OFFSET, MOD_STATUS, MOD_TIMECONST,
    STA_NANO, STA_PLL, STA_UNSYNC, timex,
};
use tracing::warn;

use crate::daemon::time::{Duration, Instant, tsc::Skew};

/// Newtype wrapping `libc::timex` to provide valid
/// constructors for each type of `adjtimex`/`ntp_adjtime` operation.
#[derive(Debug, PartialEq, Clone)]
pub struct Timex(timex);

#[bon]
impl Timex {
    /// Maximum phase offset that can be submitted to the kernel PLL in a single
    /// `adjtimex` call. While the kernel itself clamps offsets to 500ms (`MAXPHASE`) in
    /// `ntp_adjtime` calls, stability calls for slewing less aggressively. This is because
    /// drastically changing the frequency can cause the monotonic clocks to speed
    /// up aggressively
    ///
    /// Using a value of 100 ms as the maximum phase offset. This correlates
    /// with a 25,000 ppm (or 2.5%) frequency offset.
    ///
    /// ref: <https://github.com/torvalds/linux/blob/master/kernel/time/ntp.c#L297-L344>
    ///
    /// The state machine also uses this value as the threshold above
    /// which a step correction is preferred over a smooth slew during startup
    pub const MAX_PHASE_OFFSET: Duration = Duration::from_millis(100);

    /// Expose a mutable reference to the inner `libc::timex`.
    pub fn expose(&mut self) -> *mut timex {
        &raw mut self.0
    }

    /// Read the given `time` from the underlying `timex`. The kernel
    /// generally returns this with the time set to the current `CLOCK_REALTIME`
    /// reading.
    ///
    /// Notably, this same field is used in `ADJ_SETOFFSET` mode calls in order to supply an
    /// offset value.
    ///
    /// The value may be expressed in microseconds by default, but if the call is made
    /// with `status` bit `STA_NANO` set, `tv_usec` represents a nanosecond value.
    pub fn time(&self) -> Instant {
        let tv = self.0.time;
        let fractional_part = if self.0.status & STA_NANO > 0 {
            Duration::from_nanos(tv.tv_usec)
        } else {
            Duration::from_micros(tv.tv_usec)
        };
        Instant::from_secs(tv.tv_sec) + fractional_part
    }

    /// Reads the given `freq` from the underlying `timex`.
    ///
    /// In struct timex, freq, ppsfreq, and stabil are ppm (parts per
    /// million) with a 16-bit fractional part, which means that a value
    /// of 1 in one of those fields actually means 2^-16 ppm, and
    /// 2^16=65536 is 1 ppm.  This is the case for both input values (in
    /// the case of freq) and output values.
    /// ref: See NOTES in <https://man7.org/linux/man-pages/man2/adjtimex.2.html>
    ///
    /// This function constructs a `Skew` value from the given `freq` value set on the `timex`.
    pub fn freq(&self) -> Skew {
        Skew::from_timex_freq(self.0.freq)
    }

    /// Returns true if the `STA_UNSYNC` status bit is set.
    pub fn is_unsync(&self) -> bool {
        self.0.status & STA_UNSYNC != 0
    }

    /// Construct a [`Timex`] struct to be passed into `ntp_adjtime`
    ///
    /// A couple notes on how it constructs
    /// - `maxerror` set to the clock error bound. Without setting, kernel will mark unsynced
    /// - `esterror` set to the clock error bound.
    #[allow(
        clippy::cast_possible_truncation,
        reason = "offset is clamped then converted so no truncation"
    )]
    pub fn from_phase_correction(mut offset: Duration, error_bound: Duration) -> Self {
        // When the offset is within bounds, this marks the clock as synchronized within the
        // kernel, assuming the clock error bound is < 16 seconds (`NTP_PHASE_LIMIT` in the kernel).
        let mut status = STA_PLL;

        if offset > Self::MAX_PHASE_OFFSET || offset < -Self::MAX_PHASE_OFFSET {
            warn!(
                offset_ns = offset.as_nanos(),
                max_phase_offset_ns = Self::MAX_PHASE_OFFSET.as_nanos(),
                "Phase offset out of bounds, clamping and marking STA_UNSYNC"
            );
            offset = offset.clamp(-Self::MAX_PHASE_OFFSET, Self::MAX_PHASE_OFFSET);
            status |= STA_UNSYNC;
        }

        Self(timex {
            modes: MOD_OFFSET | MOD_TIMECONST | MOD_NANO | MOD_STATUS | MOD_MAXERROR | MOD_ESTERROR,
            offset: offset.as_nanos_trunc(),
            freq: 0,
            maxerror: error_bound.as_micros(),
            esterror: error_bound.as_micros(),
            status,
            constant: 0,
            precision: 0,
            tolerance: 0,
            #[cfg(not(target_os = "macos"))]
            time: timeval {
                tv_sec: 0,
                tv_usec: 0,
            },
            #[cfg(not(target_os = "macos"))]
            tick: 0,
            ppsfreq: 0,
            jitter: 0,
            shift: 0,
            stabil: 0,
            jitcnt: 0,
            calcnt: 0,
            errcnt: 0,
            stbcnt: 0,
            #[cfg(not(target_os = "macos"))]
            tai: 0,
            #[cfg(not(target_os = "macos"))]
            __unused1: 0,
            #[cfg(not(target_os = "macos"))]
            __unused2: 0,
            #[cfg(not(target_os = "macos"))]
            __unused3: 0,
            #[cfg(not(target_os = "macos"))]
            __unused4: 0,
            #[cfg(not(target_os = "macos"))]
            __unused5: 0,
            #[cfg(not(target_os = "macos"))]
            __unused6: 0,
            #[cfg(not(target_os = "macos"))]
            __unused7: 0,
            #[cfg(not(target_os = "macos"))]
            __unused8: 0,
            #[cfg(not(target_os = "macos"))]
            __unused9: 0,
            #[cfg(not(target_os = "macos"))]
            __unused10: 0,
            #[cfg(not(target_os = "macos"))]
            __unused11: 0,
        })
    }

    /// Construct a `libc::timex` used for stepping the clock by some phase correction,
    /// with a full step (can go forwards or backwards).
    /// This is used to set the system clock to the current time, which is useful for
    /// initializing the clock after a reboot.
    ///
    /// `ADJ_SETOFFSET` is only supported on Linux `adjtimex`, in the future we should have some implementation
    /// for other platforms e.g. FreeBSD
    #[cfg(target_os = "linux")]
    #[allow(
        clippy::field_reassign_with_default,
        reason = "false positive, can't use default constructor for inner type fields mutated"
    )]
    #[builder]
    pub fn clock_step(phase_correction: Duration) -> Self {
        Self(timex {
            // Set `modes` bits for `ADJ_SETOFFSET` to step the clock, and MOD_NANO to use nanosecond units
            modes: ADJ_SETOFFSET | MOD_NANO,
            offset: 0,
            freq: 0,
            maxerror: 0,
            esterror: 0,
            status: 0,
            constant: 0,
            precision: 0,
            tolerance: 0,
            // `ADJ_SETOFFSET` uses `time` rather than offset field to indicate how much to step the clock
            #[cfg(not(target_os = "macos"))]
            time: phase_correction.to_timeval_nanos(),
            #[cfg(not(target_os = "macos"))]
            tick: 0,
            ppsfreq: 0,
            jitter: 0,
            shift: 0,
            stabil: 0,
            jitcnt: 0,
            calcnt: 0,
            errcnt: 0,
            stbcnt: 0,
            #[cfg(not(target_os = "macos"))]
            tai: 0,
            #[cfg(not(target_os = "macos"))]
            __unused1: 0,
            #[cfg(not(target_os = "macos"))]
            __unused2: 0,
            #[cfg(not(target_os = "macos"))]
            __unused3: 0,
            #[cfg(not(target_os = "macos"))]
            __unused4: 0,
            #[cfg(not(target_os = "macos"))]
            __unused5: 0,
            #[cfg(not(target_os = "macos"))]
            __unused6: 0,
            #[cfg(not(target_os = "macos"))]
            __unused7: 0,
            #[cfg(not(target_os = "macos"))]
            __unused8: 0,
            #[cfg(not(target_os = "macos"))]
            __unused9: 0,
            #[cfg(not(target_os = "macos"))]
            __unused10: 0,
            #[cfg(not(target_os = "macos"))]
            __unused11: 0,
        })
    }

    /// Completely zeroed, allows for retrieving the current kernel values
    pub fn retrieve() -> Self {
        Self(timex {
            modes: 0,
            offset: 0,
            freq: 0,
            maxerror: 0,
            esterror: 0,
            status: 0,
            constant: 0,
            precision: 0,
            tolerance: 0,
            #[cfg(not(target_os = "macos"))]
            time: timeval {
                tv_sec: 0,
                tv_usec: 0,
            },
            #[cfg(not(target_os = "macos"))]
            tick: 0,
            ppsfreq: 0,
            jitter: 0,
            shift: 0,
            stabil: 0,
            jitcnt: 0,
            calcnt: 0,
            errcnt: 0,
            stbcnt: 0,
            #[cfg(not(target_os = "macos"))]
            tai: 0,
            #[cfg(not(target_os = "macos"))]
            __unused1: 0,
            #[cfg(not(target_os = "macos"))]
            __unused2: 0,
            #[cfg(not(target_os = "macos"))]
            __unused3: 0,
            #[cfg(not(target_os = "macos"))]
            __unused4: 0,
            #[cfg(not(target_os = "macos"))]
            __unused5: 0,
            #[cfg(not(target_os = "macos"))]
            __unused6: 0,
            #[cfg(not(target_os = "macos"))]
            __unused7: 0,
            #[cfg(not(target_os = "macos"))]
            __unused8: 0,
            #[cfg(not(target_os = "macos"))]
            __unused9: 0,
            #[cfg(not(target_os = "macos"))]
            __unused10: 0,
            #[cfg(not(target_os = "macos"))]
            __unused11: 0,
        })
    }

    // Helper function to create a dummy Timex for `NoopClockAdjuster`.
    #[cfg(feature = "test-side-by-side")]
    pub fn create_dummy_timex() -> Timex {
        Timex(timex {
            modes: 0,
            offset: 0,
            freq: 0,
            maxerror: 0,
            esterror: 0,
            status: 0,
            constant: 0,
            precision: 0,
            tolerance: 0,
            #[cfg(not(target_os = "macos"))]
            time: timeval {
                tv_sec: 0,
                tv_usec: 0,
            },
            #[cfg(not(target_os = "macos"))]
            tick: 0,
            ppsfreq: 0,
            jitter: 0,
            shift: 0,
            stabil: 0,
            jitcnt: 0,
            calcnt: 0,
            errcnt: 0,
            stbcnt: 0,
            #[cfg(not(target_os = "macos"))]
            tai: 0,
            #[cfg(not(target_os = "macos"))]
            __unused1: 0,
            #[cfg(not(target_os = "macos"))]
            __unused2: 0,
            #[cfg(not(target_os = "macos"))]
            __unused3: 0,
            #[cfg(not(target_os = "macos"))]
            __unused4: 0,
            #[cfg(not(target_os = "macos"))]
            __unused5: 0,
            #[cfg(not(target_os = "macos"))]
            __unused6: 0,
            #[cfg(not(target_os = "macos"))]
            __unused7: 0,
            #[cfg(not(target_os = "macos"))]
            __unused8: 0,
            #[cfg(not(target_os = "macos"))]
            __unused9: 0,
            #[cfg(not(target_os = "macos"))]
            __unused10: 0,
            #[cfg(not(target_os = "macos"))]
            __unused11: 0,
        })
    }
}

impl AsRef<timex> for Timex {
    fn as_ref(&self) -> &timex {
        &self.0
    }
}

#[cfg(test)]
mod test {
    use libc::{STA_NANO, STA_UNSYNC, timeval};
    use rstest::rstest;

    use super::*;

    #[rstest]
    #[case::positive(
        Duration::from_millis(100),
        timeval {tv_sec: 0, tv_usec: 100_000_000},
    )]
    #[case::negative(
        -Duration::from_millis(100),
        timeval {tv_sec: -1, tv_usec: 900_000_000},
    )]
    #[case::zero(
        Duration::from_millis(0),
        timeval {tv_sec: 0, tv_usec: 0},
    )]
    fn test_timex_clock_step(#[case] phase_correction: Duration, #[case] expected_time: timeval) {
        let binding = Timex::clock_step()
            .phase_correction(phase_correction)
            .call();
        let tx = binding.as_ref();
        assert_eq!(tx.time, expected_time);
        // assert modes is set properly for our adjustment
        assert_eq!(tx.modes, ADJ_SETOFFSET | MOD_NANO);
    }

    // Helper function to create a Timex with custom time and status values
    fn create_timex_with_time(tv_sec: i64, tv_usec: i64, status: i32) -> Timex {
        Timex(timex {
            modes: 0,
            offset: 0,
            freq: 0,
            maxerror: 0,
            esterror: 0,
            status,
            constant: 0,
            precision: 0,
            tolerance: 0,
            #[cfg(not(target_os = "macos"))]
            time: timeval { tv_sec, tv_usec },
            #[cfg(not(target_os = "macos"))]
            tick: 0,
            ppsfreq: 0,
            jitter: 0,
            shift: 0,
            stabil: 0,
            jitcnt: 0,
            calcnt: 0,
            errcnt: 0,
            stbcnt: 0,
            #[cfg(not(target_os = "macos"))]
            tai: 0,
            #[cfg(not(target_os = "macos"))]
            __unused1: 0,
            #[cfg(not(target_os = "macos"))]
            __unused2: 0,
            #[cfg(not(target_os = "macos"))]
            __unused3: 0,
            #[cfg(not(target_os = "macos"))]
            __unused4: 0,
            #[cfg(not(target_os = "macos"))]
            __unused5: 0,
            #[cfg(not(target_os = "macos"))]
            __unused6: 0,
            #[cfg(not(target_os = "macos"))]
            __unused7: 0,
            #[cfg(not(target_os = "macos"))]
            __unused8: 0,
            #[cfg(not(target_os = "macos"))]
            __unused9: 0,
            #[cfg(not(target_os = "macos"))]
            __unused10: 0,
            #[cfg(not(target_os = "macos"))]
            __unused11: 0,
        })
    }

    #[test]
    fn test_get_time_microsecond_precision_without_sta_nano() {
        // Test that without STA_NANO flag, tv_usec is interpreted as microseconds
        let timex = create_timex_with_time(1, 123_456, 0);
        let result = timex.time();
        let expected = Instant::from_secs(1) + Duration::from_micros(123_456);
        assert_eq!(result, expected);
    }

    #[test]
    fn test_get_time_nanosecond_precision_with_sta_nano() {
        // Test that with STA_NANO flag, tv_usec is interpreted as nanoseconds
        let timex = create_timex_with_time(1, 123_456_789, STA_NANO);
        let result = timex.time();
        let expected = Instant::from_secs(1) + Duration::from_nanos(123_456_789);
        assert_eq!(result, expected);
    }

    #[test]
    fn test_get_time_zero_values() {
        // Test epoch time (zero values)
        let timex = create_timex_with_time(0, 0, 0);
        let result = timex.time();
        assert_eq!(result, Instant::UNIX_EPOCH);
    }

    #[test]
    fn test_get_time_negative_seconds() {
        // Test negative seconds (before epoch)
        let timex = create_timex_with_time(-10, 500_000, 0);
        let result = timex.time();
        let expected = Instant::from_secs(-10) + Duration::from_micros(500_000);
        assert_eq!(result, expected);
    }

    #[test]
    fn apply_phase_correction_clears_unsync_and_writes_error_bound() {
        let error_bound = Duration::from_millis(5);
        let tx = Timex::from_phase_correction(Duration::from_micros(100), error_bound);
        let inner = tx.as_ref();

        assert_eq!(
            inner.modes,
            MOD_OFFSET | MOD_TIMECONST | MOD_NANO | MOD_STATUS | MOD_MAXERROR | MOD_ESTERROR
        );
        assert_eq!(inner.status & STA_UNSYNC, 0, "STA_UNSYNC should be cleared");
        assert_ne!(inner.status & STA_PLL, 0, "STA_PLL should stay set");
        assert_eq!(inner.maxerror, error_bound.as_micros());
        assert_eq!(inner.esterror, error_bound.as_micros());
        assert!(!tx.is_unsync());
    }

    #[rstest]
    #[case::at_positive_bound(Timex::MAX_PHASE_OFFSET)]
    #[case::at_negative_bound(-Timex::MAX_PHASE_OFFSET)]
    fn from_phase_correction_at_bound_is_not_clamped(#[case] offset: Duration) {
        let tx = Timex::from_phase_correction(offset, Duration::from_millis(5));
        let inner = tx.as_ref();

        assert_eq!(inner.offset, offset.as_nanos_trunc());
        assert_eq!(inner.status, STA_PLL);
        assert!(!tx.is_unsync());
    }

    #[rstest]
    #[case::positive(
        Timex::MAX_PHASE_OFFSET + Duration::from_millis(50),
        Timex::MAX_PHASE_OFFSET
    )]
    #[case::negative(
        -Timex::MAX_PHASE_OFFSET - Duration::from_millis(50),
        -Timex::MAX_PHASE_OFFSET
    )]
    #[case::far_positive(Duration::from_secs(10), Timex::MAX_PHASE_OFFSET)]
    fn from_phase_correction_out_of_bounds_clamps_and_sets_unsync(
        #[case] offset: Duration,
        #[case] expected: Duration,
    ) {
        let tx = Timex::from_phase_correction(offset, Duration::from_millis(5));
        let inner = tx.as_ref();

        assert_eq!(inner.offset, expected.as_nanos_trunc());
        assert_ne!(
            inner.status & STA_PLL,
            0,
            "STA_PLL must stay set to keep slewing"
        );
        assert_ne!(inner.status & STA_UNSYNC, 0, "STA_UNSYNC should be set");
        assert!(tx.is_unsync());
    }
}

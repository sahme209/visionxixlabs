//! Library support for the `cbctl` command line utility.
//!
//! Only built with the `daemon` feature, as `cbctl` is.

pub mod status;
